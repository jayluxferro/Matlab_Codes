%{
 newton raphson test
%}
clc; clear;
newtonRaphson2(@myfunc, [0.1; 0.1; -0.1], 1e-6) 