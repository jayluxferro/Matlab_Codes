clc
clear all
format long
% er=2.2;
% f=10e9;
% h=0.1588*10; 
er=input('Enter the di-electric constant:');
h=input('Enter the substrate thickness (in mil)');
f=input('Enter the frequency (GHz):');
% er=3.5;
f=f*1e9;
h=h*0.0254; % in mm

wid=(3e8/(sqrt((er+1)/2)*2*f))*1000;        %in mm
e_eff=((er+1)/2)+ (((er-1)/2)* (1+((12*h)/wid))^-0.5);

l_eff=(3e8/(2*f*sqrt(e_eff)))*1000;

del_l=(((e_eff+0.3)*((wid/h)+0.264))/((e_eff-0.258)*((wid/h)+0.8)))*(0.412*h);  %in mm

L=l_eff-(2*del_l);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

la=(3e8/f)*1000;
k=(2*pi)/la;
x=k*(wid);
i1=-2+cos(x)+(x*sinint(x))+(sin(x)/x);
g1=i1/(120*pi*pi);          %Conductance

% jb=besselj(0,(k.*L.*sin(th)));
a=@(th)(((sin((x./2).*cos(th))./cos(th)).^2).*(besselj(0,(k.*L.*sin(th)))).*(sin(th)).^3);
a1=quad(a,0,pi);
g12=a1/(120*pi*pi);     %in siemens
r_in=1/(2*(g1+g12));    %in ohms

inset=(L/pi)*(acos(sqrt(50/r_in)));        %in mm

disp(['The width is:',num2str(wid),' mm'])
disp(['The length is:',num2str(L),' mm'])
disp(['The inset feed point is:',num2str(inset),' mm'])

