function S=s1pRead(filename)

% This function reads s1p files, assuming "GHZ S MA R 50".

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[FID, MESSAGE] = fopen(filename,'r'); %open File

% Read data in, ignoring ! and # lines
n=1;
while 1
    tline = fgetl(FID);
    if ~ischar(tline), break, end
    if ~strcmp(tline(1),'!') & ~strcmp(tline(1),'#')
        Stext{n}=tline;
        n=n+1;
    end

end
fclose(FID);% Close file
      
% Convert Text to Numbers.
for n=1:length(Stext)
    S(n,:)=str2num(Stext{n});
end
% Change Freq data to GHz.
S(:,1)=S(:,1)*1e9;
