function TopNs=topN(V,N)

minV = MINN(V);

TopNs=[];
for n=1:N
    [maxV,maxVi]=maxn(V);
    maxVvec=maxNsarvas(V);
    
    TopNs=[TopNs; maxVvec];
    V(maxVi)=minV-n;
end
    
    