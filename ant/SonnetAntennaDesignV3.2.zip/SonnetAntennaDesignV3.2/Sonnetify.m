function [filename, SizeOfProject]=Sonnetify(newLen, width0, prboffset, bw0, prbimp0, lam0, height, er, zin, freq, TemplateText, RunNumber, Path, LossTanD, MetCond, MetThickness)

% This function prepares the parameters, generates the sonnet project, 
% checks to see how much memory the project will use, and sends the project
% off to be simulated.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Prepare parameters to be inserted into template file
Parameters=PrepPatchVars(newLen, width0, prboffset, bw0, prbimp0, lam0, height, er, zin, freq, LossTanD, MetCond, MetThickness);

% Generate the text of the Sonnet Project.
OutputText=GenerateSonProjectText(TemplateText,Parameters); % Gen Text

% Write the text to a Sonnet Project File.
[success,filename]=WriteSonProject(OutputText,RunNumber); % Gen File

% Approximate Project Memory Usage.
SizeOfProject=CallEMtoCheckLITE(filename, Path); % Check MEM
disp(['  This project is expected to utilize ' num2str(SizeOfProject) ' MB of Memory.'])

% Simulate the Project
CallEMtoSimulate(filename, Path, RunNumber); % CALL EM
