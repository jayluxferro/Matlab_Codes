function Z=z1pRead(filename)

% This function reads z1p files, assuming "GHZ Z RI R 1.0".

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[FID, MESSAGE] = fopen(filename,'r'); %open File

% Read data in, ignoring ! and # lines
n=1;
while 1
    tline = fgetl(FID);
    if ~ischar(tline), break, end
    if ~strcmp(tline(1),'!') & ~strcmp(tline(1),'#')
        Ztext{n}=tline;
        n=n+1;
    end

end
fclose(FID);% Close file
      
% Convert Text to Numbers.
for n=1:length(Ztext)
    Z(n,:)=str2num(Ztext{n});
end
% Change Freq data to GHz.
Z(:,1)=Z(:,1)*1e9;
