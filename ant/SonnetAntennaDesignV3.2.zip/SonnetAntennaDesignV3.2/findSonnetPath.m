function Path=findSonnetPath()

Path = uigetdir('C:\', 'Please Select Sonnet Installation')


% The below code used to search the registry for the most recent Sonnet
% installation.  This has become very problematic in Vista and Windows 7.
% Therefore the user simply enters the path of Sonnet he wishes to use.

% % % Returns the path of the most recent sonnet lite
% % % installation by searching the registry.
% % 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % Author: Serhend Arvas, sarvas@syr.edu    %
% % % Part of Patch Antenna Design Code        %
% % % August 2007                              %
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 
% % CurrentDir=cd;  % Get Current Directory
% % fclose all;     % Close all open files
% %  
% % % If the file to which the registry will be exported exists, delete it.
% % if ~isempty(dir(['"' CurrentDir '\SonnetRegEntry.reg"']))
% %     system(['del "' CurrentDir '\SonnetRegEntry.reg"']);
% % end
% % 
% % vers=version; % Get the current Matlab Version
% % versnum=str2num(vers(1:3)); % Get the first two digits of the Matlab Version.
% % 
% % % Exports the portion of the Windows Registry that contains information
% % % regarding Sonnet.  The data is written to a file.
% % 
% % [Status, Result]=system(['reg.exe export "HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Sonnet Software\sonnet" "' CurrentDir '\SonnetRegEntry.reg"']);
% % 
% % % If no installation is found...
% % if isempty(dir([CurrentDir '\SonnetRegEntry.reg']))
% %    disp(['NO SONNET INSTALLATIONS FOUND.  PLEASE INSTALL SONNET OR SONNET LITE BEFORE RUNNING'])
% %    disp(['SONNET LITE CAN BE DOWNLOADED FOR FREE FROM http://www.sonnetsoftware.com          '])
% %    Path='NONE';
% %    return;
% % end
% % 
% % % The Matlab Command FOPEN works differently for some older versions of
% % % Matlab.  Open the file differently accordingly.
% % % REG outputs a text file in UTF16 format.  Matlab must be explicitly made
% % % aware of this.
% % if versnum>=7.4
% %     % Opens the registry information data exported above.
% %     warning off MATLAB:iofun:UnsupportedEncoding;
% %     [FID, MESSAGE] = fopen([CurrentDir '\SonnetRegEntry.reg'], 'r','l', 'UTF16');
% % else
% %     FID = fopen([CurrentDir '\SonnetRegEntry.reg']);
% %     FileContents = fread(FID, '*char')';
% %     fclose(FID);
% %     FileContents = native2unicode(FileContents, 'UTF-16');
% %     FID = fopen([CurrentDir '\SonnetRegEntry.reg'], 'w');
% %     fwrite(FID,FileContents);
% %     fclose(FID);
% %     FID = fopen([CurrentDir '\SonnetRegEntry.reg']);
% % end
% % 
% % 
% % 
% % 
% % % Reads in the Registry file.
% % n=1;
% % while 1
% %     tline = fgetl(FID);
% %     if ~ischar(tline), break, end
% %     RegText{n}=tline;
% %     n=n+1;
% % end
% % 
% % fclose(FID); % Closes the registry file
% % 
% % % This block grabs every other character on each line in the registry
% % % export file.  For some reason a space like character is inserted in
% % % between every character in the file.  They are removed here.
% % %SONversions=[];
% % % for n=1:length(RegText)
% % %     tline1=RegText{n};
% % %     tline=[];
% % %     for m=1:length(tline1)
% % %         if (-1)^m==1
% % %             tline=strcat(tline,tline1(m));
% % %         end
% % %     end
% % %     RegText{n}=tline;
% % % end
% % 
% % % This finds all the lines that begin the descriptions of Sonnet entries
% % InstallLines=[];
% % for n=1:length(RegText)-1
% %     tline=RegText{n};
% %     if ~isempty(strfind(tline,'HKEY_LOCAL_MACHINE\SOFTWARE\Sonnet Software\sonnet\'))
% %         InstallLines=[InstallLines n];
% %     end
% % end
% % 
% % 
% %  % This block searches for the directory and installation date of each
% %  % version of sonnet installed.
% % InstallLines=[InstallLines length(RegText)];
% % InstallNum=0;
% % for m=1:length(InstallLines)-1  
% %     if isempty(strfind(RegText{InstallLines(m)},'Sonnet]'))
% %         InstallNum=InstallNum+1;
% %         
% %         for n=InstallLines(m):InstallLines(m+1)
% %             LineNum=n;
% %             tline=RegText{LineNum};
% % 
% %             if ~isempty(strfind(tline,'InstallationDate'))
% %                 yearstr=tline(27:30);
% %                 mostr=tline(21:22);
% %                 daystr=tline(24:25);
% %                 date=datenum(str2num(yearstr),str2num(mostr),str2num(daystr));
% % 
% %                 SonInstall(InstallNum).dates= date;
% %             end
% % 
% %             if ~isempty(strfind(tline,'"SONNET_DIR"')) 
% %                 pathtext=tline(14:length(tline));
% %                 Slashes=findstr(pathtext,'\\');
% %                 for p=1:length(Slashes)
% %                     pathtext(Slashes(p))='';
% %                 end
% % 
% %                 SonInstall(InstallNum).path= pathtext;
% %             end
% %         end
% %     end
% % end
% % 
% % % This function adds the dates of installation to the "dates" vector
% %  dates=[];
% % for n=1:length(SonInstall)
% %    dates=[dates SonInstall(n).dates]; 
% % end
% % 
% % [maxd,maxdi]=max(dates); % Finds the maximum date (i.e. most recent install)
% % SonInstall=SonInstall(maxdi); % Eliminates the records of the other installs
% % Path=SonInstall.path; % Extracts the path of the most recent install.
% % 
% % % These two lines fix the STUPID "Program Files" directory name
% % % PF=findstr(Path,'ProgramFiles');
% % % PFx86=findstr(Path,'ProgramFiles(x86)');
% % % if ~isempty(PFx86)
% % %     Path=[Path(1:PF-1) 'Program Files (x86)' Path(PF+12:length(Path))];
% % % else
% % %     Path=[Path(1:PF-1) 'Program Files' Path(PF+12:length(Path))];
% % % end
% % 
% % Path=Path([(2):(length(Path)-1)]);
% % % Deletes the Exported Registry File
% % system(['del "' CurrentDir '\SonnetRegEntry.reg"']);

