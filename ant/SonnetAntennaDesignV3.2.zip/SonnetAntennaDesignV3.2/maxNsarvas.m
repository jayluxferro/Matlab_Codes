function Output=maxNsarvas(V)
%
%maxNsarvas N-D Array Maximum With Subscript Output
%
%   X = MAXN(A) returns the maximum value found as the first element followed
%   by the subscripts of A.  No knowledge about the size of A is needed prior
%   to use.
%
%   	X = [maximum(A) sub1 sub2 sub3 . . . subN];
% 
%   If the maximum appears more than once (M times), each row contains
%   the maximum followed by a set of subscripts that correspond to it.
%
%       X = [maximum(A) sub1_1 sub2_1 sub3_1 . . . subN_1]
%           [maximum(A) sub1_2 sub2_2 sub3_2 . . . subN_2]
%                                 :
%           [maximum(A) sub1_M sub2_M sub3_M . . . subN_M]
%
%   This code uses D.C. Hanselman's MAXN routine.
%   August 2007
%   Serhend Arvas, Syracuse University.
%
%   See also minNsarvas

dimens=ndims(V);
[max,idx]=maxn(V);
Vsize=size(V);
EvalString='[a';
start=double('a');
for n=1:dimens-1
    EvalString=[EvalString ', ' char(start+n)'];   
end

EvalString=[EvalString '] = ind2sub(Vsize, idx);'];
eval(EvalString);
Output=ones(length(a),1)*max;

for n=0:dimens-1
    Output=[Output eval(char(start+n))];
end