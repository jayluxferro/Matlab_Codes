function [L0,W0,DXP0,BW0,Z0,lambda0, freq, er, height, zin, LossTanD, MetCond, MetThickness]=calc_Patch(freq, er, height, zin, LossTanD, MetCond, MetThickness)

% This function calculates various parameters required to design a
% rectangular patch antenna.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ERROR checking.
if er<1.001
    disp(['    Bad Permittivity. (Less Than Or Equal To Unity.)  Assuming er = 2'])
    er=2;
end

if er>100
    disp(['    Bad Permittivity. (Greater Than 100.)  Assuming er = 2'])
    er=2;
end

if freq<=0
    disp(['    Bad Frequency.  Assuming Frequency of 1 GHz.'])
    freq=1;
end

if height<=0
    disp(['    Bad Height.  Assuming Height of 50 mils.'])
    height=50;
end

if zin <=0
    disp(['    Bad Zin.  Assuming Zin of 50 Ohms.'])
    zin=50;
end

if LossTanD<0
    disp(['    Bad Loss Tangent.  Assuming Loss Tangent of 0.0.'])
    LossTanD=0;
end

if MetCond<=0
    disp(['    Bad Metal Conductivity.  Assuming Infinite Metal Conductivity.'])
    MetCond=inf;
end

if MetThickness <0
    disp(['    Bad Metal Thickness.  Assuming Metal Thickness of 0.7 mils.'])
    MetThickness=0.7;
end

if MetThickness==0 & MetCond~=inf
    disp(['    ERROR.  Zero Metal Thickness with Finite Metal Conductivity.  Assuming Infinite Conductivity.'])
    MetCond=inf;
end
f=freq*1e9; % Change f to GHz

c=2.9986e8*100/2.54; % Convert c to inch
lambda0=c/f; % Calc free space wavelength
L0=.49*lambda0/sqrt(er); % The first estimate of length for a rect patch.

w=(.5:.001:1.5)*L0; % Set up a swept width vector
dxp=(.05:.001:.5)*L0; % Set up a swept offset (of probe port) vector

[W,DXP]=meshgrid(w,dxp); % Generate all combinations of the vectors.

 % This is the input impedence of a rect patch given its width and port
 % offset.
ZA=90/(er-1)*(er*L0*cos(pi*DXP/L0)./W).^2;

Zcost=abs(zin-ZA); % This is the error (deviation) from the desired Zin

[minINcol,row]=min(Zcost); % Find the min in each col
[minINrow,col]=min(minINcol); % Find the min among the mins

W0=w(col); % This is the width at which the error is minumum.
DXP0=dxp(row(col)); % This is the offset at which the error is minumum.

% This is the projected BW for this design
BW0=3.77*(er-1)/(er*er)*W0/L0*height/1000/lambda0 * 100;  

% The project input impedence for this design.
Z0=ZA(row(col),col);


