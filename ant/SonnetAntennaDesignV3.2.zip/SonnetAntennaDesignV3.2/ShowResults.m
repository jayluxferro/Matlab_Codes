function h1=ShowResults(RunNumber,Fres,DesignZin,dimensions)

% This function displays the results of the design process.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Max Figure Number is currently 30
scrsz = get(0,'ScreenSize');
xLen=scrsz(3)*.9;
yLen=scrsz(4)*.6;
yLenWin=yLen/2;
xLenWin=xLen/3;
CurrentDir=cd; % Current Directory

% Read in data
S=s1pRead([CurrentDir '\SonnetProjectFiles\PatchAnt' num2str(RunNumber) '.s1p']);
Z=z1pRead([CurrentDir '\SonnetProjectFiles\PatchAnt' num2str(RunNumber) '_1.s1p']);


Smag=(S(:,2)); % S11 magnitude
 %Since the circuit is passive, this clips the return loss to 1.
 %Gamma greater than one arises due to the interpolated ABS data.
Smag(find(Smag>1-1e-6))=1-1e-6;
Sang=S(:,3);

% These lines "Renormalize" the S parameters from a 50 Ohm System (the
% Sonnet Default) to a Zin System (where Zin is the desired input impedence
% provided by the user.)
Scplx=Smag.*exp(j*Sang*pi/180);
Zinput=50*((1+Scplx)./(1-Scplx));
ScplxNew=(Zinput-DesignZin)./(DesignZin+Zinput);
Smag=abs(ScplxNew);
VSWR=(1+Smag)./(1-Smag);  % Calc VSWR
Freqs=S(:,1); % Frequency data.


% VSWR FULL VIEW
h1=figure('Name','VSWR','NumberTitle','off');; %Open a Window
set(h1,'Position',[2*xLenWin+xLenWin*.15 yLenWin+yLenWin*.5 xLenWin yLenWin]) % Set its position and size.
set(h1,'Color',[0 0 0]) % Set its background color.
h2=plot(Freqs/1e9,VSWR); % Draw a curve
set(get(h2,'Parent'),'Color',[0 0 0]); % Set color of axis background
set(get(h2,'Parent'),'XColor',[1 1 1]); % Set color of Vertical grid lines
set(get(h2,'Parent'),'YColor',[1 1 1]); % Set color of Horizontal Grid lines
set(h2,'Color',[0 1 0]) % Set color of curve.
h3=title('VSWR vs Frequency ');
h4=xlabel('F (GHz)');
h5=ylabel('VSWR');
set(h3,'Color',[1 1 1]); % Set colors of above text
set(h4,'Color',[1 1 1]);
set(h5,'Color',[1 1 1]);
grid on
axis tight
axis([min(Freqs/1e9) max(Freqs/1e9) 1 200])

% Gamma FULL VIEW
h12=figure('Name','Return Loss','NumberTitle','off');;
set(h12,'Position',[xLenWin+xLenWin*.1 yLenWin+yLenWin*.5 xLenWin yLenWin])
set(h12,'Color',[0 0 0])
h13=plot(Freqs/1e9,20*log10(Smag)); % Plot Return Loss
set(get(h13,'Parent'),'Color',[0 0 0]);
set(get(h13,'Parent'),'XColor',[1 1 1]);
set(get(h13,'Parent'),'YColor',[1 1 1]);
set(h13,'Color',[0 1 0])
h14=title('\Gamma vs Frequency ');
h15=xlabel('F (GHz)');
h16=ylabel('\Gamma (dB)');
set(h14,'Color',[1 1 1]);
set(h15,'Color',[1 1 1]);
set(h16,'Color',[1 1 1]);
grid on
axis tight


% Find indices for which the VSWR is less than 3
Bandi=find(VSWR<3);  
if length(Bandi)<2
    [Band,Bandi]=min(Smag);
    Bandi=[Bandi-4:Bandi+4];
end

% VSWR Zoomed in.
h6=figure('Name','VSWR in Band','NumberTitle','off');;
set(h6,'Position',[2*xLenWin+xLenWin*.15 yLenWin*.15 xLenWin yLenWin])
set(h6,'Color',[0 0 0])
h7=plot(Freqs(Bandi)/1e9,VSWR(Bandi)); % Plot those VSWR points.
set(get(h7,'Parent'),'Color',[0 0 0]);
set(get(h7,'Parent'),'XColor',[1 1 1]);
set(get(h7,'Parent'),'YColor',[1 1 1]);
set(h7,'Color',[0 1 0])
h8=title('VSWR vs Frequency ');
h9=xlabel('F (GHz)');
h10=ylabel('VSWR');
set(h8,'Color',[1 1 1]);
set(h9,'Color',[1 1 1]);
set(h10,'Color',[1 1 1]);
hold on
% Draw a line to show the VSWR = 2 line.
h11=line([Freqs(Bandi(1)) Freqs(Bandi(length(Bandi)))]/1e9,[2 2]);
set(h11,'Color',[1 0 1]);
set(h11,'LineWidth',3);
grid on
axis tight
ylim([1 3])


% Zin Real Zoomed in.
h17=figure('Name','Input Impedence','NumberTitle','off');;
set(h17,'Position',[xLenWin+xLenWin*.1 yLenWin*.15 xLenWin yLenWin])
set(h17,'Color',[0 0 0])
h18=plot(Freqs(Bandi)/1e9,real(Zinput(Bandi))); % Plot Real(Zin)
set(get(h18,'Parent'),'Color',[0 0 0]);
set(get(h18,'Parent'),'XColor',[1 1 1]);
set(get(h18,'Parent'),'YColor',[1 1 1]);
set(h18,'Color',[0 1 0])
h19=title('Re(Z_i_n) vs Frequency ');
h20=xlabel('F (GHz)');
h21=ylabel('Re(Z_i_n) (\Omega)');
set(h19,'Color',[1 1 1]);
set(h20,'Color',[1 1 1]);
set(h21,'Color',[1 1 1]);
hold on
% Plot desired Zin Line
h22=line([Freqs(Bandi(1)) Freqs(Bandi(length(Bandi)))]/1e9,[DesignZin DesignZin]);
set(h22,'Color',[1 0 1]);
set(h22,'LineWidth',3);
grid on
axis tight



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  DRAW THE WHOLE BOX AND PATCH %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BoxLen=dimensions(1,1);
BoxWidth=dimensions(1,2);
BoxHeight=dimensions(2,1);
SubThickness=dimensions(3,1);
PatchXs=dimensions(4:8,1);
PatchYs=dimensions(4:8,2);

ProbeXs=dimensions(9:13,1);
ProbeYs=dimensions(9:13,2);

h23=figure('Name','Sonnet Project','NumberTitle','off');
set(h23,'Position',[xLenWin*.05 yLenWin+yLenWin*.5 xLenWin yLenWin])
set(h23,'Color',[1 1 1])
hold on
BoxColor=[0 1 0];
h23a=fill3([0 BoxLen BoxLen 0],[0 0 BoxWidth BoxWidth],BoxHeight*[1 1 1 1],[0 1 0]); % top surface of box
h23b=fill3([0 BoxLen BoxLen 0],[0 0 0 0],[0 0 BoxHeight BoxHeight],BoxColor); % side1 surface of box
h23c=fill3([0 BoxLen BoxLen 0],BoxWidth*[1 1 1 1],[0 0 BoxHeight BoxHeight],BoxColor); % side2 surface of box
h23d=fill3([0 0 0 0],[0 0 BoxWidth BoxWidth],[0 BoxHeight BoxHeight 0],BoxColor); % side3 surface of box
h23e=fill3(BoxLen*[1 1 1 1],[0 0 BoxWidth BoxWidth],[0 BoxHeight BoxHeight 0],BoxColor); % side4 surface of box
h23f=fill3([0 BoxLen BoxLen 0],[0 0 BoxWidth BoxWidth],[0 0 0 0],BoxColor); % bottom surface of box
set(h23a,'FaceAlpha',.01)
set(h23b,'FaceAlpha',0)
set(h23c,'FaceAlpha',0)
set(h23d,'FaceAlpha',0)
set(h23e,'FaceAlpha',0)
set(h23f,'FaceAlpha',0)

SubstrateColor=[1 0 0];
SubXs=[[0 BoxLen BoxLen 0] ; [0 BoxLen BoxLen 0] ; [0 BoxLen BoxLen 0] ;[0 0 0 0]; BoxLen*[1 1 1 1] ; [0 BoxLen BoxLen 0]]';
SubYs=[[0 0 BoxWidth BoxWidth]; [0 0 0 0]; BoxWidth*[1 1 1 1];[0 0 BoxWidth BoxWidth]; [0 0 BoxWidth BoxWidth]; [0 0 BoxWidth BoxWidth] ]';
SubZs=[SubThickness*[1 1 1 1];[0 0 SubThickness SubThickness];[0 0 SubThickness SubThickness];[0 SubThickness SubThickness 0];[0 SubThickness SubThickness 0]; [0 0 0 0]]';

h25=fill3(SubXs,SubYs,SubZs,SubstrateColor);
set(h25,'FaceAlpha',.1);

h26=fill3([PatchXs(1:4)],[PatchYs(1:4)],[1 1 1 1]*SubThickness,[0 0 1]); % Antenna patch
set(h26,'FaceAlpha',.5)

for p=1:length(ProbeXs)-1
    fill3([ProbeXs(p) ProbeXs(p+1) ProbeXs(p+1) ProbeXs(p)],[ProbeYs(p) ProbeYs(p+1) ProbeYs(p+1) ProbeYs(p)],[0 0 1 1]*SubThickness,[1 0 0]);
end

title('Sonnet Project Box and Antenna');
xlabel('Length (in)');
ylabel('Width (in)');
zlabel('Height (in)');
view(-30,30)
grid on
axis image vis3d
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  END OF (DRAW THE WHOLE BOX AND PATCH) %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  DRAW JUST THE PATCH %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h27=figure('Name','Patch Antenna','NumberTitle','off');
set(h27,'Position',[xLenWin*.05 yLenWin*.15 xLenWin yLenWin])
set(h27,'Color',[1 1 1])
hold on

% SubstrateColor=[1 0 0];
% SubXs=[[0 BoxLen BoxLen 0] ; [0 BoxLen BoxLen 0] ; [0 BoxLen BoxLen 0] ;[0 0 0 0]; BoxLen*[1 1 1 1] ; [0 BoxLen BoxLen 0]]'*.1+ .45*BoxLen;
% SubYs=[[0 0 BoxWidth BoxWidth]; [0 0 0 0]; BoxWidth*[1 1 1 1];[0 0 BoxWidth BoxWidth]; [0 0 BoxWidth BoxWidth]; [0 0 BoxWidth BoxWidth] ]'*.1+ .45*BoxWidth;
% SubZs=[SubThickness*[1 1 1 1];[0 0 SubThickness SubThickness];[0 0 SubThickness SubThickness];[0 SubThickness SubThickness 0];[0 SubThickness SubThickness 0]; [0 0 0 0]]';
% 
% h28=fill3(SubXs,SubYs,SubZs,SubstrateColor);
% set(h28,'FaceAlpha',.1);

h29a=fill3([[PatchXs(1:4)]-mean(PatchXs(1:4))]*1.2+mean(PatchXs(1:4)),[[PatchYs(1:4)]-mean(PatchYs(1:4))]*1.2+mean(PatchYs(1:4)),[0 0 0 0],[1 1 1]); % Ground Under Antenna patch
set(h29a,'FaceAlpha',.1);

h29=fill3([PatchXs(1:4)],[PatchYs(1:4)],[1 1 1 1]*SubThickness*1.01,[0 0 1]); % Antenna patch
set(h29,'FaceAlpha',.5);


for p=1:length(ProbeXs)-1
    hprobe=fill3([ProbeXs(p) ProbeXs(p+1) ProbeXs(p+1) ProbeXs(p)],[ProbeYs(p) ProbeYs(p+1) ProbeYs(p+1) ProbeYs(p)],[0 0 1 1]*SubThickness*1.01,[1 0 0]);
    set(hprobe,'EdgeColor',[0 1 0]);
end

title('Zoomed in on the Patch ');
xlabel('Length (in)');
ylabel('Width (in)');
zlabel('Height (in)');
view(-35,24)
grid on
axis([min(PatchXs)*.75 max(PatchXs)*1.25 min(PatchYs)*.75 ,max(PatchYs)*1.25])

% Xmin=min(PatchXs)
% Xmax=max(PatchXs)
% Ymin=min(PatchYs)
% Ymax=max(PatchYs);
% Xs=[Xmin:(Xmax-Xmin)/10:Xmax];
% Ys=[Ymin:(Ymax-Ymin)/10:Ymax];
% Zmid=SubThickness*1.5;
% Zmin=SubThickness*1.1;
% Zmax=SubThickness*1.9;
% XmaxProbe=max(ProbeXs);
% YProbe=mean([Ymin Ymax]);
% 
% h30=line(Xs(1:5),Ymax*ones(1,5),ones(1,5)*Zmid);set(h30,{'Color','LineWidth'},{[0 0 0],2})
% h31=line(Xs(7:11),Ymax*ones(1,5),ones(1,5)*Zmid);set(h31,{'Color','LineWidth'},{[0 0 0],2})
% h32=line(Xmax*ones(1,5),Ys(1:5),ones(1,5)*Zmid);set(h32,{'Color','LineWidth'},{[0 0 0],2})
% h33=line(Xmax*ones(1,5),Ys(7:11),ones(1,5)*Zmid);set(h33,{'Color','LineWidth'},{[0 0 0],2})
% h34=line([1 1]*Xmin,[1 1]*Ymax,[Zmin Zmax]);set(h34,{'Color','LineWidth'},{[0 0 0],2})
% h35=line([1 1]*Xmax,[1 1]*Ymax,[Zmin Zmax]);set(h35,{'Color','LineWidth'},{[0 0 0],2})
% h36=line([1 1]*Xmax,[1 1]*Ymin,[Zmin Zmax]);set(h36,{'Color','LineWidth'},{[0 0 0],2})
% 
% h37=line([1 1]*Xmin,[1 1]*YProbe,[Zmin Zmax]);set(h37,{'Color','LineWidth'},{[0 0 0],2})
% h38=line([1 1]*XmaxProbe,[1 1]*YProbe,[Zmin Zmax]);set(h38,{'Color','LineWidth'},{[0 0 0],2})
% h39=line([Xmin XmaxProbe],[1 1]*YProbe,[1 1]*Zmid);set(h39,{'Color','LineWidth'},{[0 0 0],2})
% 
% h40=text(Xs(5),Ymax,Zmax,['Length = ' num2str(Xmax-Xmin) ' (in)']);set(h40,{'Color','FontSize'},{[0 0 0],[12]});
% h41=text(Xmax,Ys(5),Zmax,['Width = ' num2str(Ymax-Ymin) ' (in)']);set(h41,{'Color','FontSize'},{[0 0 0],[12]});
% h42=text(XmaxProbe+.05*(Xmax-Xmin),YProbe,Zmax,['Probe Pos = ' num2str(XmaxProbe-Xmin) ' (in)']);set(h42,{'Color','FontSize'},{[0 0 0],[12]});
axis image vis3d


hold off


disp('Drawing Figures.')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  END OF (DRAW JUST THE PATCH) %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


