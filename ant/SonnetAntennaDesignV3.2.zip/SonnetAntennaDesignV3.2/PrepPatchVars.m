function Parameter=PrepPatchVars(len0, width0, prboffset0, bw0, prbimp0, lam0, height, er, zin, freq, LossTanD, MetCond, MetThickness)

% This function prepares the parameters that will be written to the Sonnet
% Project File.  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Current Highest Parameter number is 40.

Parameter(1) = freq*.99;  % Start of Discrete Sweep
Parameter(2) = freq*1.01; % End of Discrete Sweep
Parameter(32) = freq*.01; %  Step of Discrete Sweep  

Parameter(33) = freq * 0.7; %  Start of the Sweep band.
Parameter(34) =  freq * 1.3; % End of Sweep Band.

Parameter(35) = LossTanD;
Parameter(36) = MetCond;
Parameter(37) = MetThickness/1000;
Parameter(38) = 50;
Parameter(39) = 50;
Parameter(40) = 50;

CellsPerSideOfAntenna=100;
CellsPerSideOfBox=1500;

CellXLen=len0/CellsPerSideOfAntenna;
CellYLen=width0/CellsPerSideOfAntenna;

Parameter(3) = CellXLen*CellsPerSideOfBox; % The length of the enclosing box (roughly 2 lambda)
Parameter(4) = CellYLen*CellsPerSideOfBox;    % The width of the enclosing box (roughly 2 lambda) 

Parameter(5) = CellsPerSideOfBox; % Number of Squares along the length of the box. (100 * length)
Parameter(6) = CellsPerSideOfBox; % Number of Squares along the width of the box. (100 * width)

Parameter(7) = lam0 / 2; % Top of box (Emperical Data Suggests lambda / 2)

Parameter(8) = height / 1000; % Thickness of Substrate
Parameter(9) = er; % Relative Permittivity of Substrate

PatchCenter=[Parameter(3)/2 Parameter(4)/2];
PatchCornerTL=[PatchCenter(1)-len0/2 PatchCenter(2)+width0/2]; % Top Left Corner
PatchCornerTR=[PatchCenter(1)+len0/2 PatchCenter(2)+width0/2]; % Top Right Corner
PatchCornerBL=[PatchCenter(1)-len0/2 PatchCenter(2)-width0/2]; % Bottom Left Corner
PatchCornerBR=[PatchCenter(1)+len0/2 PatchCenter(2)-width0/2]; % Bottom Right Corner

PatchMidLeft=mean([PatchCornerTL; PatchCornerBL]); % The left edge center is the mean of the left corners

% Center of the via port is prboffset to the right of 
% the middle of the left edge of the patch
PortCenter=PatchMidLeft + [prboffset0 0];

%theta=0:(2*pi)/10:2*pi;
%x=PortCenter(1) + .03 * Parameter(7) * cos(theta);
%y=PortCenter(2) + .03 * Parameter(7) * sin(theta);

Parameter(10) = PortCenter(1)-CellXLen; % The X coordinate of the middle of the first segment of the via port
Parameter(11) = PortCenter(2)+CellYLen; % The Y coordinate of the middle of the first segment of the via port

Parameter(12) = PatchCornerTL(1); % x coordinate of the First point on the patch (starts TL, goes CCwise)
Parameter(13) = PatchCornerTL(2); % y coordinate of the First point on the patch (starts TL, goes CCwise)
Parameter(14) = PatchCornerBL(1); % x coordinate of the Second point on the patch (starts TL, goes CCwise)
Parameter(15) = PatchCornerBL(2); % y coordinate of the Second point on the patch (starts TL, goes CCwise)
Parameter(16) = PatchCornerBR(1); % x coordinate of the Third point on the patch (starts TL, goes CCwise)
Parameter(17) = PatchCornerBR(2); % y coordinate of the Third point on the patch (starts TL, goes CCwise)
Parameter(18) = PatchCornerTR(1); % x coordinate of the Fourth point on the patch (starts TL, goes CCwise)
Parameter(19) = PatchCornerTR(2); % y coordinate of the Fourth point on the patch (starts TL, goes CCwise)
Parameter(20) = PatchCornerTL(1); % x coordinate of the First point on the patch (starts TL, goes CCwise)
Parameter(21) = PatchCornerTL(2); % y coordinate of the First point on the patch (starts TL, goes CCwise)

PortCornerTL=[PortCenter(1)-CellXLen*2 PortCenter(2)+CellYLen*2]; % Top Left Corner
PortCornerTR=[PortCenter(1)+CellXLen*2 PortCenter(2)+CellYLen*2]; % Top Right Corner
PortCornerBL=[PortCenter(1)-CellXLen*2 PortCenter(2)-CellYLen*2]; % Bottom Left Corner
PortCornerBR=[PortCenter(1)+CellXLen*2 PortCenter(2)-CellYLen*2]; % Bottom Right Corner

Parameter(22) = PortCornerTL(1); % x coordinate of the First point on the patch (starts TL, goes CCwise)
Parameter(23) = PortCornerTL(2); % y coordinate of the First point on the patch (starts TL, goes CCwise)
Parameter(24) = PortCornerBL(1); % x coordinate of the Second point on the patch (starts TL, goes CCwise)
Parameter(25) = PortCornerBL(2); % y coordinate of the Second point on the patch (starts TL, goes CCwise)
Parameter(26) = PortCornerBR(1); % x coordinate of the Third point on the patch (starts TL, goes CCwise)
Parameter(27) = PortCornerBR(2); % y coordinate of the Third point on the patch (starts TL, goes CCwise)
Parameter(28) = PortCornerTR(1); % x coordinate of the Fourth point on the patch (starts TL, goes CCwise)
Parameter(29) = PortCornerTR(2); % y coordinate of the Fourth point on the patch (starts TL, goes CCwise)
Parameter(30) = PortCornerTL(1); % x coordinate of the First point on the patch (starts TL, goes CCwise)
Parameter(31) = PortCornerTL(2); % y coordinate of the First point on the patch (starts TL, goes CCwise)

