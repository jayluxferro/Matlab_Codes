function Found=SearchFile(filename,txt)

% This file returns true if the file with name "filename" exists AND the
% text in txt is in the file.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Found=0;

if isempty(dir(filename))
   return;
end

%Open the template file for reading.
[FID, MESSAGE] = fopen(filename,'r');  


n=1;
while 1
    tline = fgetl(FID);  % read a single line
    
    if ~ischar(tline), break, end % stop reading if the last line is read.
    if ~isempty(strfind(tline,txt))
        Found=1;
        fclose(FID); % Close the file.
        return;
    end
end

fclose(FID); % Close the file.
        
     