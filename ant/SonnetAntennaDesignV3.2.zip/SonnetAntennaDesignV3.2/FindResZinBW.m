function [Fres, Zin, BW]=FindResZinBW(RunNumber,DesignZin)

% This function finds the resonance frequency, the input impedence at the
% resonance frequency and the VSWR 2:1 Bandwidth

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrentDir=cd; %Current Dir.

% Read in data.
S=s1pRead([CurrentDir '\SonnetProjectFiles\PatchAnt' num2str(RunNumber) '.s1p']);
Z=z1pRead([CurrentDir '\SonnetProjectFiles\PatchAnt' num2str(RunNumber) '_1.s1p']);

% Frequency data.
Freqs=S(:,1);

Smag=S(:,2); % |S11|
 %Since the circuit is passive, this clips the return loss to 1.
 %Gamma greater than one arises due to the interpolated ABS data.
Smag(find(Smag>1-1e-6))=1-1e-6;
Sang=S(:,3);

% These lines "Renormalize" the S parameters from a 50 Ohm System (the
% Sonnet Default) to a Zin System (where Zin is the desired input impedence
% provided by the user.)
Scplx=Smag.*exp(j*Sang*pi/180);
Zinput=50*((1+Scplx)./(1-Scplx));
ScplxNew=(Zinput-DesignZin)./(DesignZin+Zinput);
Smag=abs(ScplxNew);

Freqs=S(:,1); % Frequency data.

minSi=[];

for n=2:length(Smag)-1
    if Smag(n-1)>Smag(n) & Smag(n+1)>Smag(n)
        minSi=[minSi n];
    end
end

if isempty(minSi)
    [minS,minSi]=min(Smag);
end

[minminSi, minminSii]=min(Smag(minSi));

minSi=minSi(minminSii);

minSFreq=Freqs(minSi); % Frequency of |S11| Min

Fres=minSFreq; % F resonance

Zin=Z(minSi,2); % Zin at F Resonance

VSWR=(1+Smag)./(1-Smag); % VSWR at F Res
BWFreqs=Freqs(find(VSWR<2)); % Find indices of F where VSWR < 2

% Calculate a bandwidth
if length(BWFreqs>1)
    BW=(BWFreqs(length(BWFreqs))-BWFreqs(1))/Fres*100;
else
    BW=.001;
end















