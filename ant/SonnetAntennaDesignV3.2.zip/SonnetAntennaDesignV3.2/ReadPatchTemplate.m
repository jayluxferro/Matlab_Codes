function TemplateText=ReadPatchTemplate()

% This file extracts the contents of the PatchTemplate.son file.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrentDir=cd; % Get current Directory.

if isempty(dir([CurrentDir '\PatchTemplate.son']))
   disp(['NO TEMPLATE FILE FOUND.  PLEASE PLACE THE TEMPLATE FILE IN THE CURRENT DIRECTORY'])
   TemplateText='NONE';
   return;
end

%Open the template file for reading.
[FID, MESSAGE] = fopen([ CurrentDir '\patchtemplate.son'],'r');  


n=1;
while 1
    tline = fgetl(FID);  % read a single line
    if ~ischar(tline), break, end % stop reading if the last line is read.
    TemplateText{n}=tline; % assign the most recent line to a cell array 
    n=n+1;
end

fclose(FID); % Close the file.
        
        