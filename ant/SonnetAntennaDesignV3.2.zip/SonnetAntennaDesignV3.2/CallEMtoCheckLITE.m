function SizeOfProject=CallEMtoCheckLITE(filename, Path)

% This function runs Sonnet EM partially.  Only the estimated memory
% information is extracted.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrentDir=cd; % Current Directory

name=filename(length(CurrentDir)+2:length(filename)-4);  % name of .son file

SysCall=['"' Path '\bin\em.exe" -N "' filename '"']; % Preparing the system call that will be made

[success, Output]=system(SysCall); % Run Sonnet EM's Subsectioning and memory estimation.

  % Find the two strings needed to isolate the size of the project
String1Loc=findstr(Output,'subsections and ');
String2Loc=findstr(Output,' MB');


String3=Output(String1Loc+15:String2Loc); % Isolate the string

SizeOfProject=str2num(String3); % Convert it to a number.


%This line may be used in future versions instead of the "em.exe -N" used above
% em.exe -Zreqlic -Zstop