function [filename, RunNumber, ParamsAndPerformance, Fres]=OptimizePatchLength(freq, zin, height, er, len0, width0, prboffset0, bw0, prbimp0, lam0, Path, TemplateText, ParamsAndPerformance, LossTanD, MetCond, MetThickness, RunNumber)

% This function is the overarching patch length optimization algorithm.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['     '])
disp(['____________________________________________________________'])
disp(['     '])
disp(['-----------  Commencing Patch Length Optimization  ---------'])
disp(['____________________________________________________________'])
disp(['     '])
disp(['     '])


FresOld=freq*1e9; % Init Design Freq.

FerrorH=-1e6;
FerrorL=1e6;
FlenHigh=len0;
FlenLow=len0;
n=0;
while FerrorH<0
    % Run a Case that is expected to be too high in frequency.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    FlenHigh=FlenHigh*.95;
    % This is the number of the first attempt.  The number
    % starts from 1000 so that the filename lengths will remain the same.
    % Keeps probe in the same relative position on the patch
    n=n+1;
    prboffset=(prboffset0/len0)*FlenHigh;
    disp(['  Simulation # ' num2str(RunNumber-1000) ])
    disp(['  Patch Length = ' num2str(FlenHigh) ' (in).'])
    [filename, SizeOfProject]=Sonnetify(FlenHigh, width0, prboffset, bw0, prbimp0, lam0, height, er, zin, freq,TemplateText,RunNumber,Path, LossTanD, MetCond, MetThickness);
    % Find the resonances.
    [FresHigh,ZinActual,BWActual]=FindResZinBW(RunNumber,zin);
    FerrorH=(FresHigh-FresOld)/(FresOld)*100; % Calc Freq error
    disp(['  Resonance Frequency = ' num2str(FresHigh/1e9) ' GHz.'])
    disp(['  Resonance Frequency Error = ' num2str(FerrorH) ' %   '])
    disp('  -----------------------------------------------------   ')
    disp('     ')
    disp('     ')
    ParamsAndPerformance=[ParamsAndPerformance; FlenHigh width0 prboffset FresHigh ZinActual BWActual ];
    RunNumber=RunNumber+1; % Attempt number
end

if n==1
    while FerrorL>0
        % Run a Case that is expected to be too Low in frequency.
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        FlenLow=FlenLow*1.05;
        % Keeps probe in the same relative position on the patch
        prboffset=(prboffset0/len0)*FlenLow;
        disp(['  Simulation # ' num2str(RunNumber-1000) ])
        disp(['  Patch Length = ' num2str(FlenLow) ' (in).'])
        [filename, SizeOfProject]=Sonnetify(FlenLow, width0, prboffset, bw0, prbimp0, lam0, height, er, zin, freq,TemplateText,RunNumber,Path, LossTanD, MetCond, MetThickness);
        % Find the resonances.
        [FresLow,ZinActual,BWActual]=FindResZinBW(RunNumber,zin);
        FerrorL=(FresLow-FresOld)/(FresOld)*100; % Calc Freq error
        disp(['  Resonance Frequency = ' num2str(FresLow/1e9) ' GHz.'])
        disp(['  Resonance Frequency Error = ' num2str(FerrorL) ' %   '])
        disp('  -----------------------------------------------------   ')
        disp('     ')
        disp('     ')
        ParamsAndPerformance=[ParamsAndPerformance; FlenLow width0 prboffset FresLow ZinActual BWActual ];
        %LengthsErrors=[LengthsErrors; FlenLow FerrorL];
        RunNumber=RunNumber+1; % Attempt number
    end
else
    [PaProws,PaPcols]=size(ParamsAndPerformance);
    FresLow=ParamsAndPerformance(PaProws-1,4);
    FlenLow=ParamsAndPerformance(PaProws-1,1);
    FerrorL=(FresLow-FresOld)/(FresOld)*100; % Calc Freq error
end
Ferror=max([FerrorL FerrorH]);
newLen=FlenLow;
n=0;
while abs(Ferror)>.01 & n<10% While the error is above .1%, keep trying
    n=n+1;
    ErrorSlope=(FerrorL-FerrorH)/(FlenLow-FlenHigh);
    newLen=FlenLow-FerrorL/ErrorSlope;

    %    newLen=mean([FlenLow FlenHigh]);
    if ~isempty(find(newLen==ParamsAndPerformance(:,1)))
        newLen=newLen*(1+(rand-.5)*.01);
    end

    % Keeps probe in the same relative position on the patch
    prboffset=(prboffset0/len0)*newLen;
    disp(['  Simulation # ' num2str(RunNumber-1000) ])
    disp(['  Patch Length = ' num2str(newLen) ' (in).'])
    [filename, SizeOfProject]=Sonnetify(newLen, width0, prboffset, bw0, prbimp0, lam0, height, er, zin, freq,TemplateText,RunNumber,Path, LossTanD, MetCond, MetThickness);

    [Fres,ZinActual,BWActual]=FindResZinBW(RunNumber,zin); % Eval Performance

    Ferror=(Fres-freq*1e9)/(freq*1e9)*100; % calc Freq Error

    %LengthsErrors=[LengthsErrors; newLen Ferror];
    ParamsAndPerformance=[ParamsAndPerformance; newLen width0 prboffset Fres ZinActual BWActual ];
    if Ferror>0
        FerrorH=Ferror;
        FlenHigh=newLen;
    elseif Ferror<0
        FerrorL=Ferror;
        FlenLow=newLen;
    end

    disp(['  Resonance Frequency = ' num2str(Fres/1e9) ' GHz.'])
    disp(['  Resonance Frequency Error = ' num2str(Ferror) ' %   '])
    disp('  -----------------------------------------------------   ')
    disp('     ')
    disp('     ')
    RunNumber=RunNumber+1; % Attempt number
end

RunNumber=RunNumber-1;

[Fres,ZinActual,BWActual]=FindResZinBW(RunNumber,zin); % Eval performance again


disp(['     '])
disp(['____________________________________________________________'])
disp(['     '])
disp(['-----------  Patch Length Optimization Completed   ---------'])
disp(['____________________________________________________________'])
disp(['     '])
disp(['     '])

% Final Report
disp('  ---------------------------------------------  ')
disp('  ------           R E P O R T         --------  ')
disp('  ---------------------------------------------  ')
disp(['  Patch Length = ' num2str(newLen) ' (in). '])
disp(['  Patch Width = ' num2str(width0) ' (in). '])
disp(['  Probe Offset = ' num2str(prboffset) ' (in). '])
disp(['  Resonance Frequency = ' num2str(Fres/1e9) ' GHz.'])
disp(['  Resonance Frequency Error = ' num2str((Ferror)) ' %   '])
disp(['  Input Impedence = ' num2str(ZinActual) ' Ohms '])
disp(['  Input Impedence Error = ' num2str(abs((ZinActual-zin)/zin*100)) ' %   '])
disp(['  VSWR 2:1 Bandwidth = ' num2str(BWActual) '    '])
disp('  ---------------------------------------------   ')
disp(['  Project Filename = ' filename '    '])
disp('  ---------------------------------------------   ')
disp('  ---------------------------------------------   ')
disp('  ---------------------------------------------  ')
disp('     ')



