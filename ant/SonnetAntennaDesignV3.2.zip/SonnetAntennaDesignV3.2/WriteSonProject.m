function [successful,filename]=WriteSonProject(OutputText,RunNumber)

% This function writes the Sonnet Project text to a file.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrentDir=cd; % Finds the Current Directory

% Constructs the FileName
filename=[CurrentDir '\SonnetProjectFiles\PatchAnt' num2str(RunNumber) '.son']; 
fid=fopen(filename,'w'); % Opens the file

% Sets a flag based on the success or failure of the open operation
if fid == -1
    successful = 0;
else
    successful = 1;
end

% writes the lines of the project file followed by newline characters.
for lineNum=1:length(OutputText)   
    line=OutputText{lineNum};
    fprintf(fid,line); 
    fprintf(fid,'\n');  
end

fclose(fid);  % Closes the file.

