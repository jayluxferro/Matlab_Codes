function OutputText=GenerateSonProjectText(TemplateText,Parameters)

% This function generates the text that will be written to the Sonnet
% Project.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



OutputText=TemplateText; % Initialize the OutputText
for paramNum = 1:length(Parameters)  % Step over each Parameter
    for lineNum=1:length(TemplateText) % Step over each Line

        line=OutputText{lineNum};  % Access each line individually
        
        % Find the word VARIABLE"N" in the Template File. Where "N" is the
        % number of the parameter to be placed in the text.
        if paramNum<10
            patternLoc=strfind(line,['VARIABLE0' num2str(paramNum)]);
        else
            patternLoc=strfind(line,['VARIABLE' num2str(paramNum)]);
        end

        % If the correct Variable has been found on a line, replace it with
        % its value.
        if ~isempty(patternLoc)           
            OutputText{lineNum}=[line(1:patternLoc-1) num2str(Parameters(paramNum)) line((patternLoc+10):length(line))];
            break
        end
        
    end
end

