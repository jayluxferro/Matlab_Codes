function dimensions=FindDims(filename)

% This file extracts the dimensions of the patch, the box and the Probe from the .son file.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrentDir=cd; % Get current Directory.

if isempty(dir([filename]))
   disp(['Error File Not Found'])
   dimensions=0;
   return;
end

%Open the .son file for reading.
[FID, MESSAGE] = fopen([filename],'r');  


n=1;
while 1
    tline = fgetl(FID);  % read a single line
    if ~ischar(tline), break, end % stop reading if the last line is read.
    SON{n}=tline; % assign the most recent line to a cell array 
    n=n+1;
end

fclose(FID); % Close the file.

rectCoords=[];
probeCoords=[];

for n=1:length(SON)
    tline=SON{n};
    if n==37
        spaces=findstr(tline,' ');
        BoxLen=str2num(tline(spaces(2):spaces(3)));
        BoxWidth=str2num(tline(spaces(3):spaces(4)));
    end
    if n==38
        one=findstr(tline,' 1 1 0 0 0 0 "Air"');
        BoxHeight=str2num(tline(1:one));        
    end
    if n==39
        one=findstr(tline,' 0 0 0 "Substrate"');
        ThicknessAndPerm=str2num(tline(1:one));       
    end
    if n>=46 & n<=50
        rectCoords=[rectCoords; str2num(tline)];
    end
    if n>=55 & n<=59
        probeCoords=[probeCoords; str2num(tline)];
    end   
        
end

dimensions=[BoxLen BoxWidth; BoxHeight(1) BoxHeight(1); ThicknessAndPerm(1) ThicknessAndPerm(1); rectCoords; probeCoords];



