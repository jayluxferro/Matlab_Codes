function [SparamFileName, ZparamFileName, YparamFileName]=CallEMtoSimulate(filename, Path, RunNumber)

%Call Sonnet Em to simulate the Sonnet Project File.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrentDir=cd; % Current Directory

name=filename(length(CurrentDir)+21:length(filename)-4);  % name of .son file

% Prep System Call to invoke EM on the .son file
SysCallEM=['"' Path '\bin\emstatus.exe" -Run "' filename '" -LogFile "' CurrentDir '\SonnetProjectFiles\sondata\PatchAnt' num2str(RunNumber) '\Emstatus.log" &'];

% Prep System Call to unlock the project.
SysCallUnlock=['"' Path '\bin\soncmd.exe" -unlock "' filename '"'];

% Prep System Call to clean the project data.
SysCallClean=['"' Path '\bin\soncmd.exe" -clean "' filename '"'];

% Prep names of output files.
SparamFileName=['"' CurrentDir '\SonnetProjectFiles\' name '.s1p"'];
ZparamFileName=['"' CurrentDir '\SonnetProjectFiles\' name '_1.s1p"'];
YparamFileName=['"' CurrentDir '\SonnetProjectFiles\' name '_2.s1p"'];
SondataDirName=[CurrentDir '\SonnetProjectFiles\sondata\' name ];
LogFileName=[SondataDirName '\Emstatus.log'];

if ~isempty(dir(filename))
    system(SysCallUnlock); % Unlock the project.
end

if ~isempty(dir(filename))
    system(SysCallClean); % Clean the project.
end

if ~isempty(dir(LogFileName))
    system(['del /Q "' LogFileName '"' ]); % Delete Log File.
end

if ~isempty(dir(SparamFileName))
    system(['del /Q ' SparamFileName]); % Delete S Params file.
end

if ~isempty(dir(YparamFileName))
    system(['del /Q ' YparamFileName]); % Delete Y Params file.
end

if ~isempty(dir(ZparamFileName))
    system(['del /Q ' ZparamFileName]); % Delete Z Params file.
end

system(SysCallEM); % Run Sonnet EM
n=0;

% Loop until the LogFile appears
while 1
    pause(1);
    n=n+1;
    if SearchFile(LogFileName,'COMPLETE:') & SearchFile(LogFileName,'Analysis completed successfully.')
        	disp(['  Electromagnetic Simulation Complete.  Simulation took ' num2str(n) ' seconds.'])
            break;
    end
end

pause(1);

if ~isempty(dir(LogFileName))
    system(['del /Q "' LogFileName '"' ]); % Delete Log File.
end

