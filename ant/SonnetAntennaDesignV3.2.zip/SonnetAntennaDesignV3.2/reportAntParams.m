function Output=reportAntParams(len0, width0, prboffset0, bw0, prbimp0, lam0, height, er, zin, freq)

% This function outputs the initial Design requirements and parameters.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['         '])
disp(['   _____INPUTS___________________________________________'])
disp(['         '])
disp(['   Height = ' num2str(height / 1000) ' in'])
disp(['   Permittivity = ' num2str(er) ' '])
disp(['   Desired Input Impedence = ' num2str(zin) ' Ohms'])
disp(['   Frequency = ' num2str(freq) ' GHz'])
disp(['   Free Space Wavelength = ' num2str(lam0) ' in'])
disp(['         '])
disp(['         '])
disp(['   _____INITIAL GUESSES___________________________________'])
disp(['         '])
disp(['   Initial Length = ' num2str(len0) ' in'])
disp(['   Initial Width = ' num2str(width0) ' in'])
disp(['   Initial Probe Offset = ' num2str(prboffset0) ' in'])
disp(['         '])
disp(['         '])
disp(['   _____EXPECTED PERFORMANCE_____________________________'])
disp(['         '])
disp(['   Input Impedence = ' num2str(prbimp0) ' Ohms'])
disp(['   2:1 VSWR Bandwidth = ' num2str(bw0) ' %'])
disp(['   ______________________________________________________'])
disp(['         '])

Output=1;