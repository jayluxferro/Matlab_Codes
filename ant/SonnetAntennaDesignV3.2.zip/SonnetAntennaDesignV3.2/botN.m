function BotNs=botN(V,N)

maxV = maxn(V);

BotNs=[];
for n=1:N
    [minV,minVi]=minn(V);
    minVvec=minNsarvas(V);
    
    BotNs=[BotNs; minVvec];
    V(minVi)=maxV+n;
end
    
    