function varargout = SonnetAntennaDesignGUI(varargin)
% SONNETANTENNADESIGNGUI M-file for SonnetAntennaDesignGUI.fig
%      SONNETANTENNADESIGNGUI, by itself, creates a new SONNETANTENNADESIGNGUI or raises the existing
%      singleton*.
%
%      H = SONNETANTENNADESIGNGUI returns the handle to a new SONNETANTENNADESIGNGUI or the handle to
%      the existing singleton*.
%
%      SONNETANTENNADESIGNGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SONNETANTENNADESIGNGUI.M with the given input arguments.
%
%      SONNETANTENNADESIGNGUI('Property','Value',...) creates a new SONNETANTENNADESIGNGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SonnetAntennaDesignGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SonnetAntennaDesignGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu    %
% Part of Patch Antenna Design Code        %
% August 2007                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Last Modified by GUIDE v2.5 22-Aug-2007 13:52:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SonnetAntennaDesignGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @SonnetAntennaDesignGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before SonnetAntennaDesignGUI is made visible.
function SonnetAntennaDesignGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SonnetAntennaDesignGUI (see VARARGIN)

% Choose default command line output for SonnetAntennaDesignGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

if strcmp(get(hObject,'Visible'),'off')
    initialize_gui(hObject, handles);
end

% UIWAIT makes SonnetAntennaDesignGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SonnetAntennaDesignGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  START  Freq Block   %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes during object creation, after setting all properties.
function Freq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function Freq_Callback(hObject, eventdata, handles)
% hObject    handle to Freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Freq as text
%        str2double(get(hObject,'String')) returns contents of Freq as a double
Freq = str2double(get(hObject, 'String'));
if isnan(Freq)
    set(hObject, 'String', '1');
    errordlg('Input must be a number','Error');
end

data = getappdata(gcbf, 'metricdata');
data.Freq = Freq;
setappdata(gcbf, 'metricdata', data);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  START  Perm Block   %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes during object creation, after setting all properties.
function Perm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Perm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function Perm_Callback(hObject, eventdata, handles)
% hObject    handle to Perm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Perm as text
%        str2double(get(hObject,'String')) returns contents of Perm as a double
Perm = str2double(get(hObject, 'String'));
if isnan(Perm)
    set(hObject, 'String', 2);
    errordlg('Input must be a number','Error');
end

data = getappdata(gcbf, 'metricdata');
data.Perm = Perm;
setappdata(gcbf, 'metricdata', data);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  START  Height Block   %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes during object creation, after setting all properties.
function Height_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function Height_Callback(hObject, eventdata, handles)
% hObject    handle to Height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Height as text
%        str2double(get(hObject,'String')) returns contents of Height as a double
Height = str2double(get(hObject, 'String'));
if isnan(Height)
    set(hObject, 'String', 50);
    errordlg('Input must be a number','Error');
end

data = getappdata(gcbf, 'metricdata');
data.Height = Height;
setappdata(gcbf, 'metricdata', data);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  START  Zin Block   %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes during object creation, after setting all properties.
function Zin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Zin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function Zin_Callback(hObject, eventdata, handles)
% hObject    handle to Zin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Zin as text
%        str2double(get(hObject,'String')) returns contents of Zin as a double
Zin = str2double(get(hObject, 'String'));
if isnan(Zin)
    set(hObject, 'String', 50);
    errordlg('Input must be a number','Error');
end
data = getappdata(gcbf, 'metricdata');
data.Zin = Zin;
setappdata(gcbf, 'metricdata', data);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  START  GenSim Block   %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in GenSim.
function GenSim_Callback(hObject, eventdata, handles)
% hObject    handle to GenSim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
data = getappdata(gcbf, 'metricdata');
GenerateSimulate(data.Freq, data.Zin, data.Height, data.Perm, data.LossTangentD, data.MetalCond, data.MetalThickness);



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
initialize_gui(gcbf, handles);


function initialize_gui(fig_handle, handles)
data.Height = 50;
data.Freq = 1;
data.Perm = 2;
data.Zin = 50;
data.LossTangentD = 0.0013;
data.MetalCond = inf;
data.MetalThickness = 0.7;
setappdata(fig_handle, 'metricdata', data);

set(handles.Freq, 'String', data.Freq);
set(handles.Perm, 'String', data.Perm);
set(handles.Height, 'String', data.Height);
set(handles.Zin, 'String', data.Zin);
set(handles.MetalCond, 'String', data.MetalCond);
set(handles.MetalThickness, 'String', data.MetalThickness);
set(handles.LossTangentD, 'String', data.LossTangentD);






function MetalCond_Callback(hObject, eventdata, handles)
% hObject    handle to MetalCond (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MetalCond as text
%        str2double(get(hObject,'String')) returns contents of MetalCond as a double
MetalCond = str2double(get(hObject, 'String'));
if isnan(MetalCond)
    set(hObject, 'String', 50);
    errordlg('Input must be a number','Error');
end
data = getappdata(gcbf, 'metricdata');
data.MetalCond = MetalCond;
setappdata(gcbf, 'metricdata', data);


% --- Executes during object creation, after setting all properties.
function MetalCond_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MetalCond (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function MetalThickness_Callback(hObject, eventdata, handles)
% hObject    handle to MetalThickness (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MetalThickness as text
%        str2double(get(hObject,'String')) returns contents of MetalThickness as a double
MetalThickness = str2double(get(hObject, 'String'));
if isnan(MetalThickness)
    set(hObject, 'String', 50);
    errordlg('Input must be a number','Error');
end
data = getappdata(gcbf, 'metricdata');
data.MetalThickness = MetalThickness;
setappdata(gcbf, 'metricdata', data);


% --- Executes during object creation, after setting all properties.
function MetalThickness_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MetalThickness (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function LossTangentD_Callback(hObject, eventdata, handles)
% hObject    handle to LossTangentD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LossTangentD as text
%        str2double(get(hObject,'String')) returns contents of LossTangentD as a double
LossTangentD = str2double(get(hObject, 'String'));
if isnan(LossTangentD)
    set(hObject, 'String', 50);
    errordlg('Input must be a number','Error');
end
data = getappdata(gcbf, 'metricdata');
data.LossTangentD = LossTangentD;
setappdata(gcbf, 'metricdata', data);

% --- Executes during object creation, after setting all properties.
function LossTangentD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LossTangentD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


