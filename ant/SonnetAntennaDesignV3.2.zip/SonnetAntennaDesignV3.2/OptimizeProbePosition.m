function [filename, RunNumber, ParamsAndPerformance, Fres]=OptimizeProbePosition(freq, zin, height, er, len, width, prboffset, bw0, prbimp0, lam0, Path, TemplateText, ParamsAndPerformance, RunNumber, LossTanD, MetCond, MetThickness)

% This function is the probe position optimization algorithm.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['     '])
disp(['____________________________________________________________'])
disp(['     '])
disp(['----------  Commencing Probe Position Optimization  --------'])
disp(['____________________________________________________________'])
disp(['     '])
disp(['     '])




[PaPRows,PaPCols]=size(ParamsAndPerformance);
NumberOfSteps=10;
RunNumberStart=RunNumber;
ZinActual=ParamsAndPerformance(PaPRows,5);
ZerrorOld=(ZinActual-zin)/(zin)*100; % Calc Zin error
len=ParamsAndPerformance(PaPRows,1);
width=ParamsAndPerformance(PaPRows,2);

for n=NumberOfSteps-1:-1:0

    prboffset=n*(len/2)*(1/NumberOfSteps);
    disp(['  Simulation # ' num2str(RunNumber-1000) ])
    disp(['  Probe Position = ' num2str(prboffset) ' (in).'])
    [filename, SizeOfProject]=Sonnetify(len, width, prboffset, bw0, prbimp0, lam0, height, er, zin, freq,TemplateText,RunNumber,Path, LossTanD, MetCond, MetThickness);
    % Find the resonances.
    [Fres,ZinActual,BWActual]=FindResZinBW(RunNumber,zin);
    Zerror=(ZinActual-zin)/(zin)*100; % Calc Zin error
    disp(['  Real(Zin) = ' num2str(ZinActual) ' (Ohm).'])
    disp(['  Zin Error = ' num2str(Zerror) ' %   '])
    disp('  -----------------------------------------------------   ')
    disp('     ')
    disp('     ')
    ParamsAndPerformance=[ParamsAndPerformance; len width prboffset Fres ZinActual BWActual ];

    RunNumber=RunNumber+1; % Attempt number
    if sign(Zerror)~=sign(ZerrorOld)
        break
    else
        ZerrorOld=Zerror;
    end

end

[PaPRows,PaPCols]=size(ParamsAndPerformance);

if (sign(Zerror)~=sign(ZerrorOld)) % means a change of sign was detected
    % In this scenario, I will search between the two errors where the sign of the error flipped.
    minError=1e6;
    PosAndError=[ParamsAndPerformance(PaPRows,[3 5]) ;ParamsAndPerformance(PaPRows-1,[3 5])];
    PosAndError(:,2)=(PosAndError(:,2)-zin)/(zin)*100; % Calc Zin error
    PosAndError=sortrows(PosAndError,2);
    ZerrorH=PosAndError(2,2);
    ZerrorL=PosAndError(1,2);
    PosH=PosAndError(2,1);
    PosL=PosAndError(1,1);
    n=0;
    while abs(minError)>1 & n<10
        PosSlope=(ZerrorH-ZerrorL)/(PosH-PosL);
        NewPos=-ZerrorH/PosSlope+PosH;
        n=n+1;
        % Call Sonnet...
        disp(['  Simulation # ' num2str(RunNumber-1000) ])
        disp(['  Probe Position = ' num2str(NewPos) ' (in).'])
        [filename, SizeOfProject]=Sonnetify(len, width, NewPos, bw0, prbimp0, lam0, height, er, zin, freq,TemplateText,RunNumber,Path, LossTanD, MetCond, MetThickness);
        % Find the resonances.
        [Fres,ZinActual,BWActual]=FindResZinBW(RunNumber,zin);
        Zerror=(ZinActual-zin)/(zin)*100; % Calc Zin error
        disp(['  Real(Zin) = ' num2str(ZinActual) ' (Ohm).'])
        disp(['  Zin Error = ' num2str(Zerror) ' %   '])
        disp('  -----------------------------------------------------   ')
        disp('     ')
        disp('     ')
        ParamsAndPerformance=[ParamsAndPerformance; len width NewPos Fres ZinActual BWActual ];
        RunNumber=RunNumber+1; % Attempt number

        if (Zerror==ZerrorL) | (Zerror==ZerrorH)          
           break 
        end
        if Zerror<0
            ZerrorL=Zerror;
            PosL=NewPos;
        elseif Zerror>0
            ZerrorH=Zerror;
            PosH=NewPos;
        end
    end
else % means no change of sign was detected (error did not cross zero, -> no solution)
    % In this scenario, I will search between the two lowest errors.
    minError=1e6;
    PaP=ParamsAndPerformance(RunNumberStart-1000-1:RunNumber-1000-1,[3 5]);
    PaP(:,2)=abs(PaP(:,2)-zin)/(zin)*100;
    [BestPosError,BestPosErrori]=min(PaP(:,2));
    if BestPosErrori>0 & BestPosErrori<length(PaP)
        if PaP(BestPosErrori-1,2) < PaP(BestPosErrori+1,2)
            BestPositions=[PaP(BestPosErrori,:); PaP(BestPosErrori-1,:)];
        else
            BestPositions=[PaP(BestPosErrori,:); PaP(BestPosErrori+1,:)];
        end
    elseif BestPosErrori==1;
        BestPositions=[PaP(BestPosErrori,:); PaP(BestPosErrori+1,:)];
    elseif BestPosErrori==length(PaP)
        BestPositions=[PaP(BestPosErrori,:); PaP(BestPosErrori-1,:)];        
    end
    
    n=0;
    while abs(minError)>10 & n<10  % While the error is above 10% keep trying
        n=n+1;
        NewPos=mean(BestPositions(:,1));
        disp(['  Simulation # ' num2str(RunNumber-1000) ])
        disp(['  Probe Position = ' num2str(NewPos) ' (in).'])
        [filename, SizeOfProject]=Sonnetify(len, width, NewPos, bw0, prbimp0, lam0, height, er, zin, freq,TemplateText,RunNumber,Path, LossTanD, MetCond, MetThickness);
        % Find the Performance 
        [Fres,ZinActual,BWActual]=FindResZinBW(RunNumber,zin);
        Zerror=abs(ZinActual-zin)/(zin)*100; % Calc Zin error
        disp(['  Real(Zin) = ' num2str(ZinActual) ' (Ohm).'])
        disp(['  Zin Error = ' num2str(Zerror*sign(ZinActual-zin)) ' %   '])
        disp('  -----------------------------------------------------   ')
        disp('     ')
        disp('     ')
         ParamsAndPerformance=[ParamsAndPerformance; len width NewPos Fres ZinActual BWActual ];
        RunNumber=RunNumber+1; % Attempt number        
        if Zerror==minError
            break;
        end
        if Zerror<BestPositions(1,2)
            BestPositions(1,1)=NewPos;
            BestPositions(1,2)=Zerror;
        elseif Zerror<BestPositions(2,2)
            BestPositions(2,1)=NewPos;
            BestPositions(2,2)=Zerror;
        else
            [minError,minErrori]=min(BestPositions(:,2));
            NewPos=BestPositions(minErrori,1);
            break;
        end      
        minError=min(BestPositions(:,2));
    end
end


RunNumber=RunNumber-1;

[Fres,ZinActual,BWActual]=FindResZinBW(RunNumber,zin); % Eval performance again

disp(['     '])
disp(['____________________________________________________________'])
disp(['     '])
disp(['----------  Probe Position Optimization Completed   --------'])
disp(['____________________________________________________________'])
disp(['     '])
disp(['     '])


% Final Report
disp('  ---------------------------------------------  ')
disp('  ------           R E P O R T         --------  ')
disp('  ---------------------------------------------  ')
disp(['  Patch Length = ' num2str(len) ' (in). '])
disp(['  Patch Width = ' num2str(width) ' (in). '])
disp(['  Probe Offset = ' num2str(NewPos) ' (in). '])
disp(['  Resonance Frequency = ' num2str(Fres/1e9) ' GHz.'])
disp(['  Input Impedence Approximately = ' num2str(ZinActual) ' Ohms '])
disp(['  Maximum Input Impedence Error = ' num2str(abs((ZinActual-zin)/zin*100)) ' %   '])
disp(['  VSWR 2:1 Bandwidth = ' num2str(BWActual) '    '])
disp('  ---------------------------------------------   ')
disp(['  Project Filename = ' filename '    '])
disp('  ---------------------------------------------   ')
disp('  ---------------------------------------------   ')
disp('  ---------------------------------------------  ')
disp('     ')



