
Run SonnetAntennaDesignGUI.m to get started.