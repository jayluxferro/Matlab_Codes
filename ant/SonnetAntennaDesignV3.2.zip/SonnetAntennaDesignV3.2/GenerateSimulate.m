function Ferror=GenerateSimulate(freq, zin, height, er, LossTanD, MetCond, MetThickness)

% This is the Main function

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Serhend Arvas, sarvas@syr.edu
% Part of Patch Antenna Design Code
% August 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['         True Electromagnetic Antenna Design Using Sonnet '])
disp(['        '])
disp(['                     Serhend Arvas (Aug 2007)                '])
disp(['        '])
disp(['        '])
disp(['This program will take in your design specifications. (goals, materials, etc.)'])
disp(['After estimating the patch length, patch width, and probe placement,'])
disp(['a Sonnet Project file is written, and Sonnet is called.  Sonnet performs '])
disp(['a true ELECTROMAGNETIC simulation on the design, and returns various '])
disp(['performance parameters.  Based on this data, the program alters the design and '])
disp(['resubmits the project to Sonnet.  This is repeated until the antenna is tuned to '])
disp(['the correct frequency.  Probe placement for tuning input impedance is performed'])
disp(['in a similar manner.  '])
disp([' '])
disp(['Extention of the code (by the user) to enable tuning of the patch width '])
disp(['is encouraged. '])
disp(['         '])
disp(['NOTE:  If you are using SonnetLite, the maximum memory usage allowed is 16MB. '])
disp(['         '])
disp(['         '])

TimeStart=clock; % Start a timer.
CurrentDir=cd;
SonDir=[ CurrentDir '\SonnetProjectFiles'];

if isempty(dir(SonDir))
    [Success,Message,MessageID]=mkdir(SonDir);
else
    [Success,Message,MessageID]=rmdir(SonDir, 's');
    [Success,Message,MessageID]=mkdir(SonDir);
end

Path=findSonnetPath; % Finds the path of the most recent Sonnet via the registry
if strcmp(Path,'NONE')
    Ferror=1e6;
    return;
end

TemplateText=ReadPatchTemplate; % Reads the template project.
if strcmp(TemplateText,'NONE')
    Ferror=1e6;
    return;
end

% Calculate the initial patch parameters.
[len0, width0, prboffset0, bw0, prbimp0, lam0, freq, er, height, zin, LossTanD, MetCond, MetThickness]=calc_Patch(freq, er, height, zin, LossTanD, MetCond, MetThickness);
% Report the patch parameters.
reportAntParams(len0, width0, prboffset0, bw0, prbimp0, lam0, height, er, zin, freq);

% Initialize an array that is used to store coordinates in the parameters
% space and their associated errors.
ParamsAndPerformance=[]; % This is the data structure to store each variable
%to be optimized along with it's relavent performance.
% [PatchLength  PatchWidth ProbePosition ResonantFrequency InputImpedence BandWidth]
% Each element above is a column.  Each row corresponds with a Sonnet Sim.


RunNumber=1001;

% This function does all the work to optimize the length (and hence the
% resonances frequency of the patch.
[filename, RunNumber, ParamsAndPerformance, Fres]=OptimizePatchLength(freq, zin, height, er, len0, width0, prboffset0, bw0, prbimp0, lam0, Path, TemplateText, ParamsAndPerformance, LossTanD, MetCond, MetThickness, RunNumber);
[PaProws,PaPcols]=size(ParamsAndPerformance);
PatchLengthTuned=ParamsAndPerformance(PaProws,1);
% This function does all the work to optimize the probe position.
[filename, RunNumber, ParamsAndPerformance, Fres]=OptimizeProbePosition(freq, zin, height, er, PatchLengthTuned, width0, prboffset0, bw0, prbimp0, lam0, Path, TemplateText, ParamsAndPerformance, RunNumber+1, LossTanD, MetCond, MetThickness);

[PaProws,PaPcols]=size(ParamsAndPerformance);
ProbePosTuned=ParamsAndPerformance(PaProws,3);

[filename, RunNumber, ParamsAndPerformance, Fres]=OptimizePatchLength(freq, zin, height, er, PatchLengthTuned, width0, ProbePosTuned, bw0, prbimp0, lam0, Path, TemplateText, ParamsAndPerformance, LossTanD, MetCond, MetThickness, RunNumber+1);


% Extract the dimensions from the .son file
dimensions=FindDims(filename);
% Call the performance graphs.
h1=ShowResults(RunNumber,Fres,zin,dimensions);


TimeDone=clock; % End Timer.

% Report completion time.
disp(['Patch Antenna Design Completed in ' num2str(etime(TimeDone,TimeStart)) ' seconds.']);

