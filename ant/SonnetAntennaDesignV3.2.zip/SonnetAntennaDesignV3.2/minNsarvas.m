function Output=minNsarvas(V)
%
%minNsarvas N-D Array Minimum With Subscript Output
%
%   X = MINN(A) returns the minimum value found as the first element followed
%   by the subscripts of A.  No knowledge about the size of A is needed prior
%   to use.
%
%   	X = [minimum(A) sub1 sub2 sub3 . . . subN];
% 
%   If the minimum appears more than once (M times), each row contains
%   the minimum followed by a set of subscripts that correspond to it.
%
%       X = [minimum(A) sub1_1 sub2_1 sub3_1 . . . subN_1]
%           [minimum(A) sub1_2 sub2_2 sub3_2 . . . subN_2]
%                                 :
%           [minimum(A) sub1_M sub2_M sub3_M . . . subN_M]
%
%   This code uses D.C. Hanselman's MINN routine.
%   August 2007
%   Serhend Arvas, Syracuse University.
%
%   See also maxNsarvas


dimens=ndims(V);
[min,idx]=minn(V);
Vsize=size(V);
EvalString='[a';
start=double('a');
for n=1:dimens-1
    EvalString=[EvalString ', ' char(start+n)'];   
end

EvalString=[EvalString '] = ind2sub(Vsize, idx);'];
eval(EvalString);
Output=ones(length(a),1)*min;

for n=0:dimens-1
    Output=[Output eval(char(start+n))];
end