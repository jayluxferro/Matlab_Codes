clear % Clear workspace
c = 3e8; % Speed of light in vacuum
per = input('Substrate Permitivity='); % Substrate dielectric constant
l = input('Patch length(cm)=').*1e-2; % Patch length befor strain
w = input('Patch width(cm)=').*1e-2; % Patch width befor strain
h = input('Substrate thickness(mm)=').*1e-3; % Substrate thickness
s = input('Strain(%)='); % Strain
pr = input('Substrate poisson ratio='); % Substrate poisson ratio
eper = ((per+1)./2)+(((per-1)./2).*((1+12.*(h./w)).^-0.5)); % Effective permittivity befor strain
dl = (0.412.*h).*(((eper+0.3).*((w/h)+0.264))./((eper-0.258).*((w./h)+0.8))); % To calculate effective length befor strain
le = l+(2.*dl); % Effective length befor strain
fr = c./(2.*le.*sqrt(eper)); % Frequency before strain
% After strain in the direction of antenna length
hs = h.*(1-pr.*s); % Substrate thickness after strain
ls = l.*(1+s); % Patch length after strain
ws = w.*(1-pr.*s); % Patch width after strain
epers = ((per+1)./2)+(((per-1)./2).*((1+12.*(hs./ws)).^-0.5)); % Effective permittivity after strain
dls = (0.412.*hs).*(((epers+0.3).*((ws/hs)+0.264))./((epers-0.258).*((ws./hs)+0.8))); % To calculate effective length after strain
les = ls+(2.*dls); % Effective length after strain
frsl = c./(2.*les.*sqrt(epers)); % Frequency after strain
dfrl = frsl-fr; % Frequency shift
frshl = dfrl./frsl; % Frequency shift percentage
% After strain in the direction of antenna width
hs = h.*(1-pr.*s); % Substrate thickness after strain
ls = l.*(1-pr.*s); % Patch length after strain
ws = w.*(1+s); % Patch width after strain
epers = ((per+1)./2)+(((per-1)./2).*((1+12.*(hs./ws)).^-0.5)); % Effective permittivity after strain
dls = (0.412.*hs).*(((epers+0.3).*((ws/hs)+0.264))./((epers-0.258).*((ws./hs)+0.8))); % To calculate effective length after strain
les = ls+(2.*dls); % Effective length after strain
frsw = c./(2.*les.*sqrt(epers)); % Frequency after strain
dfrw = frsw-fr; % Frequency shift
frshw = dfrw./frsw; % Frequency shift percentage
plot(s,frshl,s,frshw); % Plot the result