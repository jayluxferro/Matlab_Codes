%% EIRP
function y = EIRP(Pt, Gt, L)
    y = Pt - Gt - L;
end