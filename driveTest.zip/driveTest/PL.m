%% EIRP
function y = PL(EIRP, Pr)
    y = EIRP - Pr;
end