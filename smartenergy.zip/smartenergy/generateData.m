%Generating data
dataPlot
Current_Mean=mean(current)
Consumed_Power=Current_Mean*220